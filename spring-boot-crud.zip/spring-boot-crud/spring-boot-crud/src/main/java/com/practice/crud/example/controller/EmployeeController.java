package com.practice.crud.example.controller;

import com.practice.crud.example.entity.Employee;
import com.practice.crud.example.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;


    @PostMapping("/addEmp")
    public Employee addEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @PostMapping("/addEmps")
    public List<Employee> addEmployee(@RequestBody List<Employee> employee) {
        return employeeService.saveEmployees(employee);
    }
    @GetMapping("/emp")
    public List<Employee> findAllEmployess() {
        return employeeService.getEmployess();
    }
    @GetMapping("/empById/{id}")
    public Employee findEmployeeById(@PathVariable int id) {
        return employeeService.getEmployeeById(String.valueOf(id));
    }

    @PutMapping("/update")
    public Employee updateEmployee(@RequestBody Employee employee) {
        return employeeService.updateEmployee(employee);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable String id) {
        return employeeService.deleteEmployee(id);
    }
}
