package com.practice.crud.example.service;

import com.practice.crud.example.entity.Employee;
import com.practice.crud.example.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee
    ) {
        return employeeRepository.save(employee);
    }

    public List<Employee> saveEmployees(List<Employee> employee) {
        return employeeRepository.saveAll(employee);
    }

    public List<Employee> getEmployess() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(String id) {
        return employeeRepository.findById(Integer.valueOf(id)).orElse(null);
    }

    public String deleteEmployee(String id) {
        employeeRepository.deleteById(Integer.valueOf(id));
        return "employee removed !! " + id;
    }
    public Employee updateEmployee(Employee employee) {
        Employee existingEmployee = employeeRepository.findById(Integer.valueOf(employee.getId())).orElse(null);
        existingEmployee.setFirstName(employee.getFirstName());
        existingEmployee.setLastName(employee.getLastName());
        existingEmployee.setEmail(employee.getEmail());
        existingEmployee.setAge(employee.getAge());
        return employeeRepository.save(existingEmployee);
    }


}
