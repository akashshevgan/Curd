package com.practice.crud.example.repository;

import com.practice.crud.example.entity.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface EmployeeRepository extends MongoRepository<Employee,Integer> {

}

